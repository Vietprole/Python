auth_type = 'Bearer'
consumerID = ''
consumerSecret = ''

url = 'https://fc-data.ssi.com.vn/'
stream_url = 'https://fc-datahub.ssi.com.vn/'